#include<iostream>
#include"1.cpp"
#include"2.cpp"
#include"3.cpp"
#include"4.cpp"

using namespace std;

int main()
{
   
    firstcpp();
    secondcpp();
    thirdcpp();
    fourthcpp();
    return 0;
    
}


